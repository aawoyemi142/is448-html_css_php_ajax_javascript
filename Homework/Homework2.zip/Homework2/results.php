<!DOCTYPE html>
<html>
<head>
    <title>Survey Results</title>
    <link rel="stylesheet" href="custom.css">
</head>

<body>
<!-- Display stored survey results -->
<div class="center-box">
    <h2>Survey Results</h2>
    
    <?php
    // Define file path
    // Path to the songs.txt file
    $path = "/afs/umbc.edu/users/a/a/aawoyem1/pub/text-files/songs.txt";

    // Check if file exists and read its content
    if (file_exists($file)) {
        $lines = file($file);
        if (count($lines) > 0) {
            echo "<ul>";
            foreach ($lines as $line) {
                echo "<li>" . htmlspecialchars($line) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>No entries yet.</p>";
        }
    } else {
        echo "<p>File not found.</p>";
    }
    ?>
    <a href="index.html">Back to Survey</a>
</div>
</body>
</html>